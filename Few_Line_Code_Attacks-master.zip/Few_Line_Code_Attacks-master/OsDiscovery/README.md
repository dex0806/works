# Os Discovery

Try to guess the OS of the target by examining some of its footprints using Nmap Python library .

# Example :
```OsDiscovery("192.168.254.25","eth0")```
