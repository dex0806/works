# Mac Flood Attack

 Sending a flood of IP packets with random IP and MAC addresses in order to overload the target MAC table
# Example :
```MacFlood("eth0",100000) ```
