# Rose Attack

Sending multiple fragmented packets with escaped offsets (missing fragmented packets) in order to simulate the Rose Attack

# Example : 
``` RoseAttack("192.168.254.25","eth0",80) ```
